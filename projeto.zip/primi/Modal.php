<?php
ini_set('default_charset', 'UTF-8');
    if(isset($_GET['codigo'])){
        //Conexão com banco
        require_once('db/conexao.php');
        $conexao = conexaoMysql();
        
        mysqli_set_charset($conexao, "utf8");
        $codigo = $_GET['codigo'];

        $sql = "SELECT codigo, descricao,foto,CAST(preco AS DECIMAL(16,2)) as preco,nome,cod_loja FROM tbl_produto where codigo=".$codigo;
        $select = mysqli_query($conexao, $sql);
        
        //Record Set = retorno de dados do banco
        
        if($rsprodutos = mysqli_fetch_array($select)){
            $nome = $rsprodutos['nome'];
            $desc = $rsprodutos['descricao'];
            $foto = $rsprodutos['foto'];
            $preco = $rsprodutos['preco'];
			$loja = $rsprodutos['cod_loja'];
			
			$sql = "select nome_empresa from tbl_loja  where codigo = ".$loja;
			$select = mysqli_query($conexao, $sql);
			if($rsloja = mysqli_fetch_array($select)){
				$nome_empresa = $rsloja['nome_empresa'];
			}
			
        }
    }

?>
<html>
    <head>
        <meta charset="utf-8">
        <script>
            $(document).ready(function(){
                $('.close').click(function(){
                    $('#container').fadeOut(800);
                });					
            });           
        </script>
    </head>
    <body>
        <button class="close">
            <a href="index.php">X</a>
        </button>
        <div id="tabela-modal">
            <div class="float">
                <div><img class="imagem-modal " alt="Bicicleta" title="Bicicleta" src="<?php echo($foto)?>"></div>
            </div>
            <div class="item-modal float">
                <div>
                    <div class="valor"><p><span>Nome: </span><?php echo($nome)?></p></div>
                </div>
                <div>
                    <div class="valor"><p class="por"><span>Preço: </span><?php echo("R$".$preco)?></p></div>
                </div>
                <div>
                    <div class="valor"><div class="float"><span>A venda em: </span></div><div class="float"><a href="Sobre.php"><?php echo(" ".$nome_empresa)?></a></div></div>
                </div>
                <div>
                    <div class="descr"><h2>Descrição:</h2><br><?php echo($desc) ?></div>
                </div>
            </div>
        </div>
    </body>
</html>















