<?php
    require_once('db/conexao.php');
    $conexao = conexaoMysql();
	
?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
		<meta http-equiv=”Content-Type” content=”text/html; charset=utf-8″>
        <title>Smart Games</title>
		<link rel="icon" href="imagens/logo.png">
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="css/style-slider.css">
		<link rel="stylesheet" type="text/css" href="css/style-redes.css">
		<link rel="stylesheet" type="text/css" href="css/style-modal.css">
        <link rel="stylesheet" type="text/css" href="css/style-rodape.css">
		<script src="js/jssor.slider-27.5.0.min.js"></script>
		<script src="js/slider.js"></script>
		<script src="js/jquery-3.3.1.min.js"></script>
		
        <!--script para a model-->
        <script>
			$(document).ready(function(){
				$('.detalhes').click(function(){
					$('#container').fadeIn(1000);				
				});
			});
            
            function visualizarDados(idItem){
               
                $.ajax({
                    type: "GET",
                    url: "Modal.php",
                    data: {codigo: idItem},
                    success: function (dados){
                        $('#model').html(dados);
                    }
                    
                });
            }
        </script>
    </head>
    <body>
    <!--Container Modal-->
	<div id="container">
		<div id="model" class="center">
			
		</div>
	</div>
        <!--Header Menu-->
        <header id="header">
            <nav id="caixa-menu">
                <div id="menu" class="caixa-center center">
                    <div id="nao" class="menu-itens pad">
                        <a href="index.php"><img id="logo" alt="logo" title="logo" src="imagens/logo.png"></a>
                    </div>
                    <div class="menu-itens">
                        <a href="#" class="pad">Promo&ccedil;&otilde;es</a>
                    </div>
                    <div class="menu-itens">
                        <a href="#" class="pad">Fale Conosco</a>
                    </div>
                    <div class="menu-itens ">
                        <a href="Sobre.php" class="pad">Nossas Lojas</a>
                    </div>
					<form method="get" action="#">
						<div class="menu-itens log pad">
							<div id="usuario">Usuario<br><input required class="in" name="usuario" type="text" placeholder="Digite o seu Usuario"/></div>
						</div>
						<div class="menu-itens log pad">
						   <div id="senha">Senha<br><input required placeholder="Digite a sua senha" class="in" name="senha" type="text"/></div> 
						   <div id="bt" ><input type="submit" name="btn-login" value="Ok"/></div>
						</div>
					</form>
                </div>
            </nav>
        </header>
        <!--Caixa Slider-->
		<div id="caixa-slider">   
            <!-- Caixa Slider-->
			<div class="slider center caixa-center"><?php include("php/slide.php")?></div>
		</div>
        <!--Section do conteudo-->
        <section id="apresentacao">
            <!--Conteudo da pagina-->
			<div id="conteudo" class="caixa-center center">	
                <div id="redes-sociais">
                    <div id="f"></div>
                    <div id="w"></div>
                    <div id="i"></div>
                </div> 
                <!--Itens-->
                <div id="itens">
                    <div class="item"><p class="text2">Item1</p></div>
                    <div class="item"><p class="text2">Item2</p></div>
                </div>
                <!--Produtos a venda-->    
                <div id="produtos">
					<div><h1 id="title">Produtos em Destaque</h1></div>
					
					<?php 
					
						$sql = "SELECT codigo,IF(char_length(descricao) < 80,descricao,concat(substr(descricao,1,80),'...')) AS descricao,foto,CAST(preco AS DECIMAL(16,2)) as preco,nome,ativo FROM tbl_produto where ativo = 1";

                            //guarda o retorno do banco de dados
                            $select = mysqli_query($conexao, $sql);

                            //mysql_fetch_array transforma uma lista de retorno do banco de dados em uma matriz
                            while($rsprodutos=mysqli_fetch_array($select)){
					
					?>
						<div class="caixa-produto">
							<div class="caixa-imagem-produto"><img class="imagem" alt="jogo <?php echo($rsprodutos['nome'])?>" title="jogo <?php echo($rsprodutos['nome'])?>" src="<?php echo($rsprodutos['foto'])?>"></div>
							<div class="desc">
								<p class="text"><span class="negrito">Nome: </span><?php echo($rsprodutos['nome'])?></p>
								<p class="text"><span class="negrito">Descri&ccedil;&atilde;o: </span><?php echo($rsprodutos['descricao'])?></p>
								<p class="text"><span class="negrito">Pre&ccedil;o: </span> <span class="por"><?php echo("R$".$rsprodutos['preco'])?></span></p>
							</div>
							<div><a href="#" onclick="visualizarDados(<?php echo($rsprodutos['codigo'])?>)" class="detalhes" >Detalhes</a></div>
						</div>
					<?php
						}
					?>
                </div>
                <!--Redes sociais-->
                
            </div>
        </section>
        <!--Rodape-->
		<footer>
            <div id="conteudo-rodape" class="caixa-center center"><?php include("php/rodape.php")?></div>
        </footer>
    </body>
</html>