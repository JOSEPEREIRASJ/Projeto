<div id="link">
	<div><h2>Links</h2></div>
	<div class="item-link"><a href=""><h3>Promo&ccedil;&otilde;es</h3></a></div>
	<div class="item-link"><a href=""><h3>Fale Conosco</h3></a></div>
	<div class="item-link"><a href=""><h3>Not&iacute;cias em Destaque</h3></a></div>
	<div class="item-link"><a href=""><h3>Nossas Lojas</h3></a></div>
</div>
<div id="informacoes">
	<div><h2>Informa&ccedil;&otilde;es de contato</h2></div>
	<div class="item-info"><h3>0800 321 0707</h3></div>
	<div class="item-info"><h3>comercial@smartgames.com.br</h3></div>
	<div class="item-info"><h3>Estr. Rosa Scarpa, 65 </h3></div>					
</div>
<div id="contato">
	<div><h2>Receba nossas novidades</h2></div>
	<form method="get" action="#">
		<div id="caixa-contato">
			<div><input required id="email-cliente" type="email" name="email-cliente" placeholder="Digite seu E-mail: "/></div>
			<div><input id="receber" type="submit" name="receber" value="Receber"/></div>
		</div>
	</form>
</div>