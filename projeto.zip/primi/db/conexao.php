<?php

function conexaoMysql(){
    /*    mysql_connect() biblioteca de conexão com bd mysql, ate php 5.6
        mysqli() biblioteca de conexão com bd mysql, utilizado nas versões atuais 
        PDO() biblioteca de conexão com bd mysql, mais utilizado em projetos orientados a objetos

    */

    // Variaveis para fornecer os dados para a conexão do banco
    $server = "localhost" ;
    $user = "root";
    $password = "bcd127";
    $database = "db_loja_jogos";

    // Variavel para receber as informacoes banco
    $conexao = null;    

    //fazendo a conexão
    $conexao = mysqli_connect($server,$user,$password,$database);

    return $conexao;
}
?>