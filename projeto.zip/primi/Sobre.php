<?php
    require_once('db/conexao.php');
    $conexao = conexaoMysql();

	if(isset($_GET['bt_enviar'])){
		header('location:Sobre.php');
	}
	
?>
<!DOCTYPE html>
<html lang="pt-br">
    
    <head>
	<meta charset=utf-8″>
        <link rel="icon" href="imagens/logo.png">
		<link rel="stylesheet" type="text/css" href="css/style4.css">
        <link rel="stylesheet" type="text/css" href="css/style-redes.css">
		<link rel="stylesheet" type="text/css" href="css/style-rodape.css">
        <title>Smart Games</title>
    </head>
    <body>
        <!--Header Menu-->
        <header id="header">
            <nav id="caixa-menu">
                <div id="menu" class="caixa-center center">
                    <div id="nao" class="menu-itens pad">
                        <a href="index.php"><img id="logo" alt="logo" title="logo" src="imagens/logo.png"></a>
                    </div>
                    <div class="menu-itens">
                        <a href="#" class="pad">Promo&ccedil;&otilde;es</a>
                    </div>
                    <div class="menu-itens">
                        <a href="#" class="pad">Fale Conosco</a>
                    </div>
                    <div class="menu-itens ">
                        <a href="Sobre.php" class="pad">Nossas Lojas</a>
                    </div>
					<form method="get" action="#">
						<div class="menu-itens log pad">
							<div id="usuario">Usuario<br><input required class="in" name="usuario" type="text" placeholder="Digite o seu Usuario"/></div>
						</div>
						<div class="menu-itens log pad">
						   <div id="senha">Senha<br><input required placeholder="Digite a sua senha" class="in" name="senha" type="text"/></div> 
						   <div id="bt" ><input type="submit" name="btn-login" value="Ok"/></div>
						</div>
					</form>
                </div>
            </nav>
        </header>
        <!--Section do conteudo-->
        <section id="apresentacao">	
			<!--Conteudo da pagina-->
            <div id="conteudo" class="caixa-center center">	
				<!--Sobre a empresa-->
                <div id="sobre">
					<!--Nossas lojas-->
					<div>
						<h1 class="title">Nossas Lojas</h1>
					</div>
					<div id="lojas">
					<?php 
					
						$sql = "SELECT * FROM tbl_loja where ativo = 1";

                            //guarda o retorno do banco de dados
                            $select = mysqli_query($conexao, $sql);

                            //mysql_fetch_array transforma uma lista de retorno do banco de dados em uma matriz
                            while($rsloja=mysqli_fetch_array($select)){
					
					?>
					
						<div class="caixa-lojas">
							<div><?php echo($rsloja['local_empresa']) ?></div>
							<div class="informacoes">
								<p><?php echo($rsloja['nome_empresa']) ?></p>
							</div>
						</div>
					<?php 
							}
					?>	
						
					</div>
				</div>
                <!--Redes sociais-->
                <div id="redes-sociais">
                    <div id="f"></div>
                    <div id="w"></div>
                    <div id="i"></div>
                </div> 
            </div>
        </section>
        <!--Rodape-->
        <footer>
            <div id="conteudo-rodape" class="caixa-center center"><?php include("php/rodape.php")?></div>
        </footer>
    </body>
</html>